<?php


namespace app\index\model;

use think\model;

class Navmenu extends model
{


}