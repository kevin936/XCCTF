<?php


namespace app\index\model;


use think\Model;

class Store extends Model
{


}