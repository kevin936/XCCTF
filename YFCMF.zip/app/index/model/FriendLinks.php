<?php


namespace app\index\model;

use think\model;

class FriendLinks extends model
{

}