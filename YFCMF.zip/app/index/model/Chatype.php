<?php


namespace app\index\model;
use think\model;

class Chatype extends model
{


}