<?php


namespace app\index\controller;


use think\file\UploadedFile;

class Uploads extends UploadedFile
{

}