<?php
namespace app\index\controller\tools;

use EasyWeChat\Kernel\Support\AES;

class Todousharp
{

}