<?php


namespace app\index\controll;


use app\BaseController;
use think\facade\View;

class Xcadmin extends BaseController
{
    public function index()
    {
        return view('index');
    }
    public function login()
    {

    }

}