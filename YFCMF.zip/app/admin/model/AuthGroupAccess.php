<?php

namespace app\admin\model;

use app\common\model\BaseModel;

class AuthGroupAccess extends BaseModel
{
    //
}
