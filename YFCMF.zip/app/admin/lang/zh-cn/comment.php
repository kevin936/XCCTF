<?php

return [
    'Cid'         => '文章id',
    'From_uid'    => '评论用户id',
    'To_uid'      => '文章作者id',
    'Content'     => '评论内容',
    'Like_count'  => '点赞记录',
    'Create_time' => '创建时间'
];
