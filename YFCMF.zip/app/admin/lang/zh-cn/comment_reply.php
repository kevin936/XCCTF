<?php

return [
    'Reply_id'    => '回复目标id',
    'From_id'     => '回复用户id',
    'To_id'       => '评论用户id',
    'Like_count'  => '点赞数',
    'Create_time' => '创建时间'
];
