<?php

return [
    'Cid'          => '对象uid',
    'Zid'          => '战队id',
    'Uid_img'      => '队员头像',
    'Status'       => '队员状态',
    'Position'     => '职位',
    'Score'        => '队员总分',
    'Text_content' => '申请理由',
    'Create_time'  => '创建时间'
];
