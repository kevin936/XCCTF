<?php

return [
    'Id'           => '自动编号',
    'Username'     => '用户名',
    'Password'     => '用户密码',
    'Email'        => '邮箱地址',
    'Phone'        => '手机号码',
    'Img'          => '用户头像',
    'Banner_img'   => '信息页banner',
    'Status'       => '状态',
    'Status 0'     => '待审核',
    'Status 1'     => '正常',
    'Status 2'     => '封禁',
    'Team_id'      => '所属战队',
    'Score'        => '总分',
    'Flag_count'   => '解题总数',
    'Flag_web'     => 'web已解题数',
    'Flag_misc'    => 'misc已解题数',
    'Flag_crypto'  => 'crypto已解题数',
    'Flag_pwn'     => 'pwn已解题数',
    'Flag_reverse' => 'reverse已解题数',
    'Create_time'  => '创建时间',
    'Update_time'  => '更新时间'
];
