<?php

return [
    'Id'          => '编号自增',
    'Tid'         => '题目ID',
    'Uid'         => '用户ID',
    'Team_id'     => '战队ID',
    'Type'        => '题目类型',
    'Create_time' => '创建时间'
];
