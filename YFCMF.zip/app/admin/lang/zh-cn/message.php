<?php

return [
    'Content'     => '消息标题',
    'Type'        => '类型',
    'Type 0'      => '通知',
    'Type 1'      => '消息',
    'Status'      => '消息是否一读,0为未读、1为已读',
    'Create_time' => '创建时间'
];
