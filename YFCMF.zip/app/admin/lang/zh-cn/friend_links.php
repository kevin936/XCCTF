<?php

return [
    'Url'         => '友情链接',
    'Img'         => '友情链接logo',
    'Create_time' => '创建时间'
];
