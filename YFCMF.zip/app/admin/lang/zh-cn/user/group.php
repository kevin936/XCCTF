<?php

return [
    'Name'       => '组名',
    'Rules'      => '权限节点',
    'Createtime' => '添加时间',
    'Updatetime' => '更新时间',
    'Status'     => '状态',
];
