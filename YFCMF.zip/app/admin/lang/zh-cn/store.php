<?php

return [
    'Name'        => '商品名称',
    'Spe'         => '商品规格',
    'Stock'       => '库存',
    'Shp_content' => '商品描述',
    'Score'       => '兑换积分',
    'Type'        => '类型',
    'Type 0'      => '头像框',
    'Type 1'      => '实物商品',
    'Type 2'      => '卡密',
    'Quota'       => '限购数量'
];
