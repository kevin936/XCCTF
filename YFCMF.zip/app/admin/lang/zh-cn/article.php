<?php

return [
    'Uid'           => '发文用户ID',
    'Title'         => '文章标题',
    'Content'       => '文章正文',
    'Browsing'      => '浏览量',
    'Like_count'    => '点赞数',
    'Comment_count' => '评论数',
    'Type'          => '文章分类',
    'Status'        => '文章状态',
    'Status 0'      => '待审核',
    'Status 1'      => '正常',
    'Top'           => '属性',
    'Top 0'         => '置顶',
    'Top 1'         => '推荐',
    'Top 2'         => '普通',
    'Create_time'   => '文章创建时间',
    'Update_time'   => '文章更新时间'
];
