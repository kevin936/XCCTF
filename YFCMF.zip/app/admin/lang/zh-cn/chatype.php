<?php

return [
    'Id'   => 'ID自增编号',
    'Type' => '题目分类'
];
