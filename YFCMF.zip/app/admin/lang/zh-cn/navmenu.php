<?php

return [
    'Tid'         => '父级导航id',
    'Nav_name'    => '导航菜单名称',
    'Nav_url'     => '导航链接',
    'Weigh'       => '权重',
    'Status'      => '菜单状态',
    'Status 0'    => '禁用',
    'Status 1'    => '启用',
    'Create_time' => '创建时间'
];
