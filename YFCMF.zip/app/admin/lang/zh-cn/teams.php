<?php

return [
    'Id'            => '自动编号',
    'Team_name'     => '队伍名称',
    'Team_score'    => '队伍总分',
    'Team_img'      => '队伍头像',
    'Team_leader'   => '队长',
    'Team_number'   => '队伍人数',
    'Team_status'   => '队伍状态',
    'Team_status 0' => '待审核',
    'Team_status 1' => '正常',
    'Team_status 2' => '封禁',
    'Team_content'  => '战队宣言',
    'Create_time'   => '创建时间',
    'Update_time'   => '更新时间'
];
