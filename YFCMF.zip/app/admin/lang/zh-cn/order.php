<?php

return [
    'Shp_id'      => '商品ID',
    'Uid'         => '用户id',
    'Shp_name'    => '商品名称',
    'Shp_img'     => '商品图片',
    'Shp_score'   => '商品单价',
    'Shp_unit'    => '商品数量',
    'Shp_num'     => '商品总价',
    'Name'        => '联系人',
    'Phone'       => '联系电话',
    'Address'     => '详细地址',
    'Comment'     => '备注',
    'Status'      => '订单状态',
    'Status 0'    => '交易失败',
    'Status 1'    => '兑换商品',
    'Status 2'    => '平台确认',
    'Status 3'    => '平台发货',
    'Status 4'    => '交易完成',
    'Ding'        => '物流单号',
    'Create_time' => '订单创建时间'
];
