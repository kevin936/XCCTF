<?php

return [
    'Id'            => '编号自增',
    'Action_title'  => '标题',
    'Action_text'   => '正文',
    'Action_type'   => '类型',
    'Action_type 0' => '公告',
    'Action_type 1' => '动态'
];
