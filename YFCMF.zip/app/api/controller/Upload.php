<?php


namespace app\api\controller;

use app\common\controller\Api;

class Upload
{
    public function index()
    {
        return '这里是上传方法';
    }

}