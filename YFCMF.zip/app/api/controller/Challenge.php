<?php


namespace app\api\controller;

use fast\Random;
use think\facade\Validate;
use think\facade\Config;
use app\common\library\Ems;
use app\common\library\Sms;
use app\common\controller\Api;

class Challenge extends Api
{

}